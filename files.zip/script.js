'use strict';
/* ===== Helpers & state ===== */
const $=(s,e=document)=>e.querySelector(s),$$=(s,e=document)=>[...e.querySelectorAll(s)];
const KEY='basic-english-v1';
const load=()=>{try{return JSON.parse(localStorage.getItem(KEY))||{}}catch(e){return{}}};
let S=Object.assign({xp:0,lessons:[],words:[],best:0,quizzes:0,streak:0,last:'',badges:[],daily:'',dark:false},load());
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}};
const iso=d=>new Date(d).toISOString().slice(0,10);
const BADGES={first:['🏆','First Lesson'],vocab:['📚','Vocabulary Beginner'],grammar:['✏️','Grammar Starter'],streak:['🔥','3 Day Streak'],quiz:['🎯','Quiz Master']};
function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2500)}
function badge(id){if(!S.badges.includes(id)){S.badges.push(id);toast('New badge: '+BADGES[id].join(' '))}}
function touch(){const t=iso(Date.now());if(S.last===t)return;S.streak=S.last===iso(Date.now()-864e5)?S.streak+1:1;S.last=t;if(S.streak>=3)badge('streak')}
function xp(n){S.xp+=n;touch();save();refresh()}
const pct=()=>Math.round(S.lessons.length/LESSONS.length*50+Math.min(S.words.length,50)/50*50);
function refresh(){$('#xpPill').textContent=`⭐ ${S.xp} XP · 🔥 ${S.streak}`;$('#homeBar').style.width=pct()+'%';$('#homeTxt').textContent=`${pct()}% complete · ${S.lessons.length}/${LESSONS.length} lessons · ${S.words.length} words learned`}
function speak(t){try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='en-US';u.rate=.85;speechSynthesis.speak(u)}catch(e){toast('Audio is not supported in this browser')}}
const shuffle=a=>[...a].sort(()=>Math.random()-.5);
const norm=s=>String(s).toLowerCase().replace(/[.?!,]/g,'').replace(/\s+/g,' ').trim();
const day=()=>Math.floor(Date.now()/864e5);

/* ===== Data ===== */
const VR={
Family:'father|ayah|My father is kind.;mother|ibu|My mother cooks dinner.;brother|saudara laki-laki|I have one brother.;sister|saudara perempuan|My sister is ten.;grandmother|nenek|My grandmother lives in Malang.',
School:'teacher|guru|The teacher is friendly.;book|buku|Open your book.;pencil|pensil|I need a pencil.;classroom|ruang kelas|Our classroom is clean.;homework|pekerjaan rumah|I do my homework at night.',
'Food & Drinks':'apple|apel|I eat an apple.;rice|nasi|We eat rice every day.;water|air|I drink water.;milk|susu|She likes milk.;bread|roti|He eats bread for breakfast.',
Animals:'cat|kucing|The cat is sleeping.;dog|anjing|The dog is big.;bird|burung|A bird can fly.;fish|ikan|Fish live in water.;horse|kuda|The horse runs fast.',
'Body Parts':'head|kepala|My head hurts.;hand|tangan|Wash your hands.;eye|mata|She has brown eyes.;ear|telinga|I hear with my ears.;foot|kaki|My foot is small.',
House:'door|pintu|Close the door.;window|jendela|Open the window.;kitchen|dapur|Mom is in the kitchen.;bedroom|kamar tidur|My bedroom is small.;chair|kursi|Sit on the chair.',
Clothes:'shirt|kemeja|He wears a white shirt.;shoes|sepatu|My shoes are new.;hat|topi|She wears a hat.;dress|gaun|The dress is beautiful.;socks|kaus kaki|I have blue socks.',
Hobbies:'reading|membaca|Reading is fun.;swimming|berenang|I like swimming.;drawing|menggambar|She enjoys drawing.;singing|bernyanyi|They love singing.;cooking|memasak|My dad likes cooking.',
Transportation:'bus|bus|The bus is late.;car|mobil|Dad drives a car.;bicycle|sepeda|I ride a bicycle to school.;train|kereta|The train is fast.;plane|pesawat|The plane lands at noon.',
Places:'school|sekolah|I go to school.;market|pasar|Mom goes to the market.;hospital|rumah sakit|The hospital is near.;park|taman|We play in the park.;library|perpustakaan|The library is quiet.'};
const VOCAB=[];Object.entries(VR).forEach(([c,s])=>s.split(';').forEach(x=>{const[w,m,e]=x.split('|');VOCAB.push({w,m,e,c})}));
const COLORS='Red|Merah|#ef4444;Blue|Biru|#3b82f6;Green|Hijau|#22c55e;Yellow|Kuning|#facc15;Black|Hitam|#111827;White|Putih|#ffffff;Orange|Oranye|#fb923c;Purple|Ungu|#a855f7;Pink|Merah muda|#f472b6;Brown|Cokelat|#92400e;Gray|Abu-abu|#9ca3af'.split(';').map(x=>x.split('|'));
const ALPHA='Apple,Ball,Cat,Dog,Egg,Fish,Goat,Hat,Ice,Juice,Kite,Lion,Moon,Nose,Orange,Pen,Queen,Rain,Sun,Tree,Umbrella,Van,Water,X-ray,Yellow,Zebra'.split(',');
const DAYS='Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday'.split(','),MONTHS='January,February,March,April,May,June,July,August,September,October,November,December'.split(',');
const say=(t,l=t)=>`<button class="tile" data-say="${t}"><b>${l}</b></button>`;

/* ===== Lessons ===== */
const LESSONS=[
{id:'alpha',ic:'🔤',t:'Alphabet & Pronunciation',d:'A–Z with sounds',h:()=>`<p>Klik huruf untuk mendengar bunyinya. Setiap huruf punya contoh kata.</p><div class="tiles">${ALPHA.map((w,i)=>{const L=String.fromCharCode(65+i);return `<button class="tile" data-say="${L}. ${w}"><b>${L}${L.toLowerCase()}</b><small>${w}</small></button>`}).join('')}</div><p>Tips: dengarkan, tirukan, lalu ulangi. Perhatikan bunyi akhir kata, misalnya <b>cat</b> dibaca "kæt", bukan "kat".</p>`},
{id:'greet',ic:'👋',t:'Greetings & Introduction',d:'Hello, how are you?',h:()=>`<div class="tiles">${['Hello','Hi','Good morning','Good afternoon','Good evening','Goodbye','How are you?','Nice to meet you'].map(x=>say(x)).join('')}</div><h3>Dialog</h3><div class="dlg"><p><b>Ani:</b> Good morning! My name is Ani.</p><p><b>Budi:</b> Hi, Ani. I am Budi. Nice to meet you.</p><p><b>Ani:</b> Nice to meet you too. How are you?</p><p><b>Budi:</b> I am fine, thank you. And you?</p></div><h3>Introducing yourself</h3><p><i>Hello, my name is ... I am ... years old. I am a student. I live in ...</i></p>`},
{id:'num',ic:'🔢',t:'Numbers',d:'1–100, ordinals, age & phone',h:()=>`<div class="tiles">${Array.from({length:100},(_,i)=>say(i+1)).join('')}</div><h3>Ordinal numbers</h3><p>first (1st), second (2nd), third (3rd), fourth (4th), fifth (5th), tenth (10th), twentieth (20th)</p><h3>Age</h3><p>I am fifteen years old. / She is twelve.</p><h3>Phone number</h3><p>Sebut angka satu per satu: 0812 → <i>zero eight one two</i>. Angka 0 boleh dibaca "oh".</p>`},
{id:'color',ic:'🎨',t:'Colors',d:'Red, blue, green...',h:()=>`<div class="grid">${COLORS.map(c=>`<button class="card" data-say="${c[0]}"><div class="sw" style="background:${c[2]}"></div><b>${c[0]}</b><small>${c[1]}</small></button>`).join('')}</div>`},
{id:'time',ic:'📅',t:'Days, Months & Time',d:'Calendar and clock',h:()=>`<h3>Days</h3><div class="tiles">${DAYS.map(x=>say(x)).join('')}</div><h3>Months</h3><div class="tiles">${MONTHS.map(x=>say(x)).join('')}</div><h3>Telling time</h3><p>3:00 → It is three o'clock.<br>3:15 → It is a quarter past three.<br>3:30 → It is half past three.<br>3:45 → It is a quarter to four.</p><h3>Date</h3><p>Today is Monday, October 5th. My birthday is on May 12th.</p>`},
{id:'pron',ic:'🙋',t:'Pronouns',d:'I, you, he, she...',h:()=>`<table><tr><th>Pronoun</th><th>Arti</th><th>Example</th></tr>${[['I','saya','I am a student.'],['You','kamu','You are kind.'],['We','kita/kami','We play football.'],['They','mereka','They are friends.'],['He','dia (laki-laki)','He is tall.'],['She','dia (perempuan)','She is happy.'],['It','itu (benda/hewan)','It is a cat.']].map(r=>`<tr><td><button class="chip" data-say="${r[2]}">🔊 ${r[0]}</button></td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join('')}</table>`},
{id:'tobe',ic:'🧩',t:'To Be',d:'am, is, are',h:()=>`<table><tr><th>Subject</th><th>To be</th><th>Example</th></tr><tr><td>I</td><td>am</td><td>I am a student.</td></tr><tr><td>He / She / It</td><td>is</td><td>She is happy.</td></tr><tr><td>You / We / They</td><td>are</td><td>They are friends.</td></tr></table><p>Negatif: I am not tired. Tanya: Are you ready?</p><button class="btn" data-go="grammar">Practice To Be</button>`},
{id:'present',ic:'⏰',t:'Simple Present Tense',d:'Habits and facts',h:()=>`<p>Dipakai untuk <b>kebiasaan</b> dan <b>fakta</b>.</p><table><tr><th>Type</th><th>Formula</th><th>Example</th></tr><tr><td>+</td><td>S + V1 (he/she/it + s/es)</td><td>I study English. She studies English.</td></tr><tr><td>−</td><td>S + do/does not + V1</td><td>They do not study English.</td></tr><tr><td>?</td><td>Do/Does + S + V1?</td><td>Does he study English?</td></tr></table><p>Setelah <b>does</b>, kata kerja kembali ke bentuk dasar (Does he <b>study</b>).</p>`},
{id:'vocab',ic:'📚',t:'Basic Vocabulary',d:'10 categories',h:()=>`<p>Pelajari 10 kategori kosakata dengan flashcard.</p><button class="btn" data-go="vocabulary">Open Vocabulary</button>`}];

/* ===== Questions ===== */
const m=(c,q,o,a,e)=>({c,q,o,a,e}),f=(q,a,e)=>({t:'fill',q,a,e}),ar=(q,w,a,e)=>({t:'arr',q,w,a,e}),tf=(q,a,e)=>m('Grammar',q,['True','False'],a?0:1,e);
const GP=[
m('Grammar','She ___ happy.',['am','is','are'],1,'She memakai "is".'),
m('Grammar','They ___ friends.',['is','am','are'],2,'They memakai "are".'),
f('I ___ a student. (am/is/are)','am','I memakai "am".'),
f('He ___ English every day. (study/studies)','studies','He/She/It + verb-s. Study → studies.'),
ar('Arrange the words.',['English','study','I'],'I study English','Pola: Subject + Verb + Object.'),
ar('Arrange the words.',['does','Where','she','live'],'Where does she live','Does + subject + verb dasar.'),
tf('"They is happy." is correct.',false,'Seharusnya "They are happy."'),
tf('"Does he study English?" is correct.',true,'Setelah does, kata kerja bentuk dasar.')];
const QZ=[
m('Vocabulary','What is "kucing" in English?',['Dog','Cat','Bird'],1,'Kucing = cat.'),
m('Vocabulary','What color is the sky on a clear day?',['Blue','Black','Brown'],0,'Sky is blue.'),
m('Vocabulary','"Library" means ...',['Pasar','Taman','Perpustakaan'],2,'Library = perpustakaan.'),
m('Vocabulary','Which one is a fruit?',['Apple','Chair','Door'],0,'Apple is a fruit.'),
m('Vocabulary','"Grandmother" is ...',['kakek','nenek','paman'],1,'Grandmother = nenek.'),
m('Vocabulary','Which one is transportation?',['Bus','Pencil','Hat'],0,'A bus is transportation.'),
m('Vocabulary','The 3rd month is ...',['February','March','May'],1,'January, February, March.'),
m('Grammar','I ___ a student.',['is','are','am'],2,'I + am.'),
m('Grammar','He ___ English.',['study','studies','studying'],1,'He + verb-s.'),
m('Grammar','They ___ not play football.',['do','does','is'],0,'They + do not.'),
m('Grammar','___ she like milk?',['Do','Does','Is'],1,'She + does.'),
m('Grammar','We ___ in class now.',['am','is','are'],2,'We + are.'),
m('Grammar','Choose the correct sentence.',['She go to school.','She goes to school.','She going to school.'],1,'She + goes.'),
m('Pronunciation','Which word starts with the sound of "k"?',['Cat','Hat','Egg'],0,'Cat dimulai dengan bunyi /k/.'),
m('Pronunciation','How many letters are in the English alphabet?',['24','26','28'],1,'A–Z = 26 huruf.'),
m('Pronunciation','Which word rhymes with "cat"?',['Hat','Dog','Pen'],0,'Cat dan hat sama-sama berakhiran -at.'),
m('Daily Conversation','"Good morning" is used in the ...',['morning','evening','night'],0,'Morning = pagi.'),
m('Daily Conversation','Answer: "How are you?"',['I am fine, thank you.','My name is Ani.','Goodbye.'],0,'Jawaban yang tepat adalah kabar kita.'),
m('Daily Conversation','When we meet someone new, we say ...',['Nice to meet you.','See you later.','Good night.'],0,'Nice to meet you = senang bertemu denganmu.'),
m('Daily Conversation','"What is your name?" asks about ...',['age','name','address'],1,'Name = nama.')];

/* ===== Question engine ===== */
function engine(el,qs,o){
let i=0,a=[],left=o.time||0,tm=null;
const fmt=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
const ok=(q,v)=>v!==undefined&&(q.t?norm(v)===norm(q.a):v===q.a);
const txt=(q,v)=>v===undefined?'(no answer)':q.t?v:q.o[v];
const key=q=>q.t?q.a:q.o[q.a];
if(o.time)tm=setInterval(()=>{left--;const t=$('#tm',el);if(t)t.textContent=fmt(left);if(left<=0)end()},1000);
function set(v){if(o.instant&&a[i]!==undefined)return;a[i]=v;draw()}
function draw(){
 const q=qs[i],v=a[i],done=v!==undefined,lock=o.instant&&done,right=ok(q,v);let b='';
 if(q.t==='fill')b=`<input class="inp" id="in" value="${done?v:''}" ${lock?'disabled':''} placeholder="Type your answer"><button class="btn" id="sub" ${lock?'disabled':''}>Check</button>`;
 else if(q.t==='arr')b=`<div class="ans" id="built">${done?v:''}</div><div class="chips">${q.w.map(w=>`<button class="chip" ${lock?'disabled':''}>${w}</button>`).join('')}</div><button class="btn ghost" id="rs" ${lock?'disabled':''}>Reset</button><button class="btn" id="sub" ${lock?'disabled':''}>Check</button>`;
 else b=q.o.map((t,k)=>`<button class="opt ${done&&v===k&&!o.instant?'sel':''} ${lock&&k===q.a?'ok':''} ${lock&&v===k&&!right?'bad':''}" data-k="${k}" ${lock?'disabled':''}>${t}</button>`).join('');
 el.innerHTML=`<div class="meta"><span>${o.title||''} Question ${i+1} / ${qs.length}</span>${o.time?'<span>⏱ <b id="tm">'+fmt(left)+'</b></span>':''}</div><div class="bar"><i style="width:${(i+1)/qs.length*100}%"></i></div><h3>${q.c?'['+q.c+'] ':''}${q.q}</h3>${b}${lock?`<div class="fb ${right?'good':'bad'}">${right?'✅ Correct!':'❌ Wrong. Answer: <b>'+key(q)+'</b>'}<br>${q.e||''}</div>`:''}<div>${o.instant?'':`<button class="btn ghost" id="pv" ${i?'':'disabled'}>Previous</button>`}<button class="btn" id="nx" ${o.instant&&!done?'disabled':''}>${i==qs.length-1?'Finish':'Next'}</button></div>`;
 $$('.opt',el).forEach(x=>x.onclick=()=>set(+x.dataset.k));
 const sub=$('#sub',el);if(sub)sub.onclick=()=>{const r=q.t==='fill'?$('#in',el).value.trim():$('#built',el).textContent.trim();if(r)set(r)};
 if(q.t==='arr'&&!lock){$$('.chip',el).forEach(c=>c.onclick=()=>{$('#built',el).textContent+=($('#built',el).textContent?' ':'')+c.textContent;c.disabled=true});$('#rs',el).onclick=()=>{$('#built',el).textContent='';$$('.chip',el).forEach(c=>c.disabled=false)}}
 if(q.t==='fill'&&!lock)$('#in',el).onkeydown=e=>{if(e.key==='Enter')sub.click()};
 const pv=$('#pv',el);if(pv)pv.onclick=()=>{i--;draw()};
 $('#nx',el).onclick=()=>{i<qs.length-1?(i++,draw()):end()};
}
function end(){
 clearInterval(tm);const n=qs.length,c=qs.filter((q,k)=>ok(q,a[k])).length,p=Math.round(c/n*100);
 const fb=p>=90?'Excellent!':p>=70?'Great Job!':p>=50?'Keep Practicing!':"Don't Give Up!";
 el.innerHTML=`<div class="card"><div class="score">${p}%</div><h2>${fb}</h2><p>Score: ${c} / ${n} · ✅ Correct: ${c} · ❌ Wrong: ${n-c}</p><button class="btn" id="again">Try again</button></div><h3>Review</h3>${qs.map((q,k)=>`<div class="rev ${ok(q,a[k])?'good':'bad'}"><b>${k+1}. ${q.q}</b><br>Your answer: ${txt(q,a[k])}<br>Correct answer: <b>${key(q)}</b><br><small>${q.e||''}</small></div>`).join('')}`;
 $('#again').onclick=o.again;o.done&&o.done(c,n,p);
}
draw();
}

/* ===== Pages ===== */
const R={
home(){const w=VOCAB[day()%VOCAB.length];$('#wotdW').textContent=w.w;$('#wotdM').textContent='Artinya: '+w.m;$('#wotdE').textContent='"'+w.e+'"';$('#wotdS').onclick=()=>speak(w.w+'. '+w.e);$('#homeCats').innerHTML=LESSONS.map(cardHTML).join('')},
lessons(){$('#lessonGrid').hidden=false;$('#lessonView').hidden=true;$('#lessonGrid').innerHTML=LESSONS.map(cardHTML).join('')},
vocabulary(){
 const cats=Object.keys(VR);let cat=cats[0],k=0,back=false;
 const draw=()=>{
  const d=VOCAB.filter(x=>x.c===cat),c=d[k];
  $('#cats').innerHTML=cats.map(x=>`<button class="chip ${x===cat?'on':''}" data-c="${x}">${x}</button>`).join('');
  $$('#cats .chip').forEach(b=>b.onclick=()=>{cat=b.dataset.c;k=0;back=false;draw()});
  $('#flash').innerHTML=`<p>Card ${k+1} / ${d.length}</p><div class="flip"><div class="face" id="face">${back?`${c.m}<small>${c.e}</small>`:c.w}</div></div><button class="btn ghost" id="pv">Previous</button><button class="btn" id="fl">Flip Card</button><button class="btn ghost" id="sp">🔊</button><button class="btn ghost" id="nx">Next</button>`;
  const flip=()=>{back=!back;if(back&&!S.words.includes(c.w)){S.words.push(c.w);if(S.words.length>=10)badge('vocab');xp(2)}draw()};
  $('#face').onclick=flip;$('#fl').onclick=flip;$('#sp').onclick=()=>speak(c.w+'. '+c.e);
  $('#pv').onclick=()=>{k=(k+d.length-1)%d.length;back=false;draw()};$('#nx').onclick=()=>{k=(k+1)%d.length;back=false;draw()};
  $('#wordList').innerHTML=d.map(x=>`<div class="card"><b>${x.w} <button class="chip" data-say="${x.w}. ${x.e}">🔊</button></b><span>${x.m}</span><small>${x.e}</small></div>`).join('');
 };draw()},
grammar(){const box=$('#gBox');const go=()=>engine(box,shuffle(GP),{instant:1,title:'Grammar',again:go,done:(c)=>{badge('grammar');xp(c*3)}});go()},
practice(){
 const box=$('#dBox'),d=day(),pick=(arr,n,s)=>Array.from({length:n},(_,i)=>arr[(d*7+i*13+s)%arr.length]);
 const words=pick(VOCAB,5,0),gq=pick(GP.filter(x=>!x.t),3,3),tq=pick(VOCAB,2,5).map(x=>f(`Translate to English: "${x.m}"`,x.w,`${x.m} = ${x.w}`));
 const home=()=>{box.innerHTML=`<p>${S.daily===iso(Date.now())?'✅ You finished today\'s challenge. You can practice again (no extra XP).':'Study 5 words, then answer 3 grammar and 2 translation questions.'}</p><div class="grid">${words.map(x=>`<div class="card"><b>${x.w}</b><span>${x.m}</span><small>${x.e}</small></div>`).join('')}</div><button class="btn" id="go">Start Today's Challenge</button>`;
  $('#go').onclick=()=>engine(box,[...gq,...tq],{instant:1,title:'Daily',again:home,done:c=>{if(S.daily!==iso(Date.now())){S.daily=iso(Date.now());xp(30+c*3)}}})};
 home()},
quiz(){const box=$('#qBox');const intro=()=>{box.innerHTML=`<p>20 questions · 10 minutes · Vocabulary, Grammar, Pronunciation, Daily Conversation.</p><button class="btn" id="go">Start Quiz</button>`;$('#go').onclick=()=>engine(box,shuffle(QZ),{time:600,title:'Quiz',again:intro,done:(c,n,p)=>{S.quizzes++;S.best=Math.max(S.best,p);if(p>=90)badge('quiz');xp(c*5)}})};intro()},
progress(){const b=Object.entries(BADGES);$('#pBox').innerHTML=`<div class="bar big"><i style="width:${pct()}%"></i></div><p><b>${pct()}%</b> complete</p><div class="grid"><div class="card"><b>${S.lessons.length}/${LESSONS.length}</b>Lessons done</div><div class="card"><b>${S.words.length}</b>Words learned</div><div class="card"><b>${S.best}%</b>Best quiz</div><div class="card"><b>${S.quizzes}</b>Quizzes taken</div><div class="card"><b>${S.xp} XP</b>Total XP</div><div class="card"><b>${S.streak} 🔥</b>Day streak</div></div><h2>Badges</h2><div class="grid">${b.map(([k,v])=>`<div class="card" style="opacity:${S.badges.includes(k)?1:.35}"><span class="ic">${v[0]}</span><b>${v[1]}</b></div>`).join('')}</div><button class="btn ghost" id="reset">Reset progress</button>`;
 $('#reset').onclick=()=>{if(confirm('Delete all progress?')){localStorage.removeItem(KEY);location.reload()}}}
};
const cardHTML=l=>`<button class="card" data-open="${l.id}"><span class="ic">${l.ic}</span><b>${l.t}</b><small>${l.d}</small>${S.lessons.includes(l.id)?'<em>✔ Done</em>':''}</button>`;
function openLesson(id){if(location.hash!=='#lessons')history.replaceState(null,'','#lessons');show('lessons');const l=LESSONS.find(x=>x.id===id);$('#lessonGrid').hidden=true;const v=$('#lessonView');v.hidden=false;v.innerHTML=`<button class="btn ghost" data-go="lessons" id="back">← Back</button><h2>${l.ic} ${l.t}</h2>${l.h()}<p><button class="btn" data-done="${id}" ${S.lessons.includes(id)?'disabled':''}>${S.lessons.includes(id)?'✔ Completed':'Mark as complete'}</button></p>`;$('#back').onclick=e=>{e.stopPropagation();show('lessons')}}
function show(p){$$('.page').forEach(s=>s.hidden=s.id!==p);$$('#menu a').forEach(a=>a.classList.toggle('on',a.hash==='#'+p));R[p]&&R[p]();scrollTo(0,0)}
function route(){const p=location.hash.slice(1);show(R[p]?p:'home')}
/* ===== Search ===== */
const INDEX=[...VOCAB.map(x=>({t:`${x.w} — ${x.m}`,s:x.e,go:'vocabulary'})),...LESSONS.map(l=>({t:l.t,s:l.d,open:l.id})),...GP.filter(x=>x.e).map(x=>({t:x.q,s:x.e,go:'grammar'})),{t:'She studies English.',s:'Simple Present',open:'present'},{t:'Does he study English?',s:'Simple Present',open:'present'},{t:'They are friends.',s:'To Be',open:'tobe'}];
$('#search').oninput=e=>{const q=e.target.value.toLowerCase().trim(),r=$('#results');if(!q){r.hidden=true;return}
 const hit=INDEX.filter(x=>(x.t+' '+x.s).toLowerCase().includes(q)).slice(0,8);
 r.hidden=false;r.innerHTML=hit.length?hit.map((x,i)=>`<button data-i="${INDEX.indexOf(x)}"><b>${x.t}</b><br><small>${x.s}</small></button>`).join(''):'<button disabled>No results. Try another word.</button>';
 $$('button[data-i]',r).forEach(b=>b.onclick=()=>{const x=INDEX[+b.dataset.i];r.hidden=true;$('#search').value='';x.open?openLesson(x.open):location.hash=x.go})};
/* ===== Global events ===== */
document.addEventListener('click',e=>{const t=e.target.closest('[data-say],[data-go],[data-open],[data-done]');if(!t)return;const d=t.dataset;
 if(d.say)speak(d.say);if(d.go)location.hash=d.go;if(d.open)openLesson(d.open);
 if(d.done&&!S.lessons.includes(d.done)){S.lessons.push(d.done);badge('first');xp(20);openLesson(d.done)}});
$('#theme').onclick=()=>{S.dark=!S.dark;theme();save()};
function theme(){document.documentElement.dataset.theme=S.dark?'dark':'light';$('#theme').textContent=S.dark?'☀️':'🌙'}
window.addEventListener('hashchange',route);
theme();refresh();route();
