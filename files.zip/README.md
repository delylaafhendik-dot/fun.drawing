# Basic English Learning

Interactive website for beginners (SMP–SMA) to learn basic English. Explanations are in Indonesian; examples and questions are in English.

## Features
- 9 lessons: Alphabet, Greetings, Numbers, Colors, Days/Months/Time, Pronouns, To Be, Simple Present, Vocabulary
- Vocabulary flashcards (10 categories) with pronunciation (Web Speech API)
- Grammar practice: multiple choice, fill in the blank, arrange words, true/false
- 20-question quiz with timer, previous/next, result page and answer review
- Daily English Challenge, Word of the Day, search
- XP, badges, streak, progress dashboard saved in `localStorage`
- Dark mode, responsive layout

## Technology
HTML5, CSS3, vanilla JavaScript. No server or build step.

## Run locally
Open `index.html` in your browser. (Audio uses your browser's built-in voices.)

## Deploy to GitHub Pages
1. Create a repository on GitHub and upload all files (keep `assets/`).
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then **Save**.
4. After a minute, your site is live at `https://USERNAME.github.io/REPOSITORY/`.
